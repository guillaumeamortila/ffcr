<?php

namespace CRBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class PresentationControllerTest extends WebTestCase
{
}
