<?php

namespace CRBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class TerrainControllerTest extends WebTestCase
{
}
