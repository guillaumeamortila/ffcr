<?php

namespace CRBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRBundle extends Bundle
{
}
