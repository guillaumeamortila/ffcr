<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_627299fa42cfd848fd182d99a5255e474fc3368ddd730c0603fa8257bf337c23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd0112b410ef9abb786ea92050c8a45f009c8af95abd00ea1ea020dec95b8e81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd0112b410ef9abb786ea92050c8a45f009c8af95abd00ea1ea020dec95b8e81->enter($__internal_fd0112b410ef9abb786ea92050c8a45f009c8af95abd00ea1ea020dec95b8e81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_7a94ea93d43ed606c5bf0be1bb0be8bfbd2bbd0d5ad8c813d962b75a4af5fc10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a94ea93d43ed606c5bf0be1bb0be8bfbd2bbd0d5ad8c813d962b75a4af5fc10->enter($__internal_7a94ea93d43ed606c5bf0be1bb0be8bfbd2bbd0d5ad8c813d962b75a4af5fc10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_fd0112b410ef9abb786ea92050c8a45f009c8af95abd00ea1ea020dec95b8e81->leave($__internal_fd0112b410ef9abb786ea92050c8a45f009c8af95abd00ea1ea020dec95b8e81_prof);

        
        $__internal_7a94ea93d43ed606c5bf0be1bb0be8bfbd2bbd0d5ad8c813d962b75a4af5fc10->leave($__internal_7a94ea93d43ed606c5bf0be1bb0be8bfbd2bbd0d5ad8c813d962b75a4af5fc10_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_d4bd076586dcd47e2136acef0d2a928b271184eb3f1263bdfec2083548868376 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4bd076586dcd47e2136acef0d2a928b271184eb3f1263bdfec2083548868376->enter($__internal_d4bd076586dcd47e2136acef0d2a928b271184eb3f1263bdfec2083548868376_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6850f958b7f1594698339a22d1dd874826d121e024645cc4515f63c01388c1ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6850f958b7f1594698339a22d1dd874826d121e024645cc4515f63c01388c1ca->enter($__internal_6850f958b7f1594698339a22d1dd874826d121e024645cc4515f63c01388c1ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_6850f958b7f1594698339a22d1dd874826d121e024645cc4515f63c01388c1ca->leave($__internal_6850f958b7f1594698339a22d1dd874826d121e024645cc4515f63c01388c1ca_prof);

        
        $__internal_d4bd076586dcd47e2136acef0d2a928b271184eb3f1263bdfec2083548868376->leave($__internal_d4bd076586dcd47e2136acef0d2a928b271184eb3f1263bdfec2083548868376_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_fbb042dbea9810f1f7c2d5b75c835ff772541b11fa84eb94855c895f659fa3b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fbb042dbea9810f1f7c2d5b75c835ff772541b11fa84eb94855c895f659fa3b1->enter($__internal_fbb042dbea9810f1f7c2d5b75c835ff772541b11fa84eb94855c895f659fa3b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_72287377e85acae92a903424691a33673a1dbf91a91dce671b6aba9a652f1988 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72287377e85acae92a903424691a33673a1dbf91a91dce671b6aba9a652f1988->enter($__internal_72287377e85acae92a903424691a33673a1dbf91a91dce671b6aba9a652f1988_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_72287377e85acae92a903424691a33673a1dbf91a91dce671b6aba9a652f1988->leave($__internal_72287377e85acae92a903424691a33673a1dbf91a91dce671b6aba9a652f1988_prof);

        
        $__internal_fbb042dbea9810f1f7c2d5b75c835ff772541b11fa84eb94855c895f659fa3b1->leave($__internal_fbb042dbea9810f1f7c2d5b75c835ff772541b11fa84eb94855c895f659fa3b1_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_9dbe530a85a4d8c1e7e67a1c0e12dbd715c1d568cb91f44603ab09faaa8eec68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9dbe530a85a4d8c1e7e67a1c0e12dbd715c1d568cb91f44603ab09faaa8eec68->enter($__internal_9dbe530a85a4d8c1e7e67a1c0e12dbd715c1d568cb91f44603ab09faaa8eec68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a829a5ec0bf876a6adaac3311bb7eadd8bda1b6e267c2125653ec0e78f995f47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a829a5ec0bf876a6adaac3311bb7eadd8bda1b6e267c2125653ec0e78f995f47->enter($__internal_a829a5ec0bf876a6adaac3311bb7eadd8bda1b6e267c2125653ec0e78f995f47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_a829a5ec0bf876a6adaac3311bb7eadd8bda1b6e267c2125653ec0e78f995f47->leave($__internal_a829a5ec0bf876a6adaac3311bb7eadd8bda1b6e267c2125653ec0e78f995f47_prof);

        
        $__internal_9dbe530a85a4d8c1e7e67a1c0e12dbd715c1d568cb91f44603ab09faaa8eec68->leave($__internal_9dbe530a85a4d8c1e7e67a1c0e12dbd715c1d568cb91f44603ab09faaa8eec68_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/layout.html.twig");
    }
}
