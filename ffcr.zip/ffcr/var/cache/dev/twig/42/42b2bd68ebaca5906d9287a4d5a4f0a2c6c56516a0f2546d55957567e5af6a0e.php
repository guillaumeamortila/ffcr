<?php

/* ::base.html.twig */
class __TwigTemplate_a04947d5009d507072a9ba6506ebae3c79fdd03aece5081d3ae329be8551f7d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21b51a89efdfa433b96fcfb87f6cfb4455536421f99bc79172d871d91489e6c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_21b51a89efdfa433b96fcfb87f6cfb4455536421f99bc79172d871d91489e6c0->enter($__internal_21b51a89efdfa433b96fcfb87f6cfb4455536421f99bc79172d871d91489e6c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_efc2b0a6e0ca72fc3f06a6744e7e70878e6bfa29a893636c740b36521044a04b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efc2b0a6e0ca72fc3f06a6744e7e70878e6bfa29a893636c740b36521044a04b->enter($__internal_efc2b0a6e0ca72fc3f06a6744e7e70878e6bfa29a893636c740b36521044a04b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

        <link rel=\"stylesheet\" href=\"/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css\">
        <link rel=\"stylesheet\" href=\"/css/style.css\">

        <script src=\"/js/jquery-3.2.1.js\"></script>
        <script src=\"/js/popper.min.js\"></script>
        <script src=\"/js/tether.min.js\"></script>
        <script src=\"/js/bootstrap.min.js\"></script>
        <script type=\"text/javascript\" src=\"/js/script.js\"></script>
    </head>
    <body>
        <div class=\"navbar navbar-dark bg-dark mb-4 nav-pills nav-justified\">
            <a class=\"navbar-brand\" href=\"/\" style=\"line-height:1em;font-size:1.2rem\">CHEESE ROLLING<br><span style=\"font-weight:200;letter-spacing:2px;font-size:1rem;\">Fédération Française</span></a>
            <div class=\"flex-lg-row\">
                <a class=\"navbar-brand\" href=\"/mybooks\"><i class=\"fa fa-book fa-1x\" aria-hidden=\"true\"></i>&nbsp;&nbsp;books</a>
                <a class=\"navbar-brand\" href=\"/#wifi\"><i class=\"fa fa-wifi fa-1x\" aria-hidden=\"true\"></i>&nbsp;&nbsp;Wifi</a>
            </div>
        </div>
        <div class=\"container\">
            ";
        // line 28
        $this->displayBlock('body', $context, $blocks);
        // line 29
        echo "        </div>
        <div class=\"footer flex-around position-relative\">
            <div class=\"footer-bloc\"><a class=\"text-secondary\" href=\"/\"><i class=\"fa fa-home fa-2x\" aria-hidden=\"true\"></i></a></div>
            <div class=\"footer-bloc text-muted copyright font-weight-light\">© Copyright FFCR 2018</div>
        </div>
    </body>
</html>
";
        
        $__internal_21b51a89efdfa433b96fcfb87f6cfb4455536421f99bc79172d871d91489e6c0->leave($__internal_21b51a89efdfa433b96fcfb87f6cfb4455536421f99bc79172d871d91489e6c0_prof);

        
        $__internal_efc2b0a6e0ca72fc3f06a6744e7e70878e6bfa29a893636c740b36521044a04b->leave($__internal_efc2b0a6e0ca72fc3f06a6744e7e70878e6bfa29a893636c740b36521044a04b_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_897a8c120b6b142e22adf5d50389e3e5d255cf8ed74ff735c6e8d67f62d9cc60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_897a8c120b6b142e22adf5d50389e3e5d255cf8ed74ff735c6e8d67f62d9cc60->enter($__internal_897a8c120b6b142e22adf5d50389e3e5d255cf8ed74ff735c6e8d67f62d9cc60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_702bce19de071e90272bbf0244bee2a3a8806e6d855791c3517cee807fe8e4fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_702bce19de071e90272bbf0244bee2a3a8806e6d855791c3517cee807fe8e4fb->enter($__internal_702bce19de071e90272bbf0244bee2a3a8806e6d855791c3517cee807fe8e4fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Cheese Rolling - Fédération Française de Cheese Rolling";
        
        $__internal_702bce19de071e90272bbf0244bee2a3a8806e6d855791c3517cee807fe8e4fb->leave($__internal_702bce19de071e90272bbf0244bee2a3a8806e6d855791c3517cee807fe8e4fb_prof);

        
        $__internal_897a8c120b6b142e22adf5d50389e3e5d255cf8ed74ff735c6e8d67f62d9cc60->leave($__internal_897a8c120b6b142e22adf5d50389e3e5d255cf8ed74ff735c6e8d67f62d9cc60_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2eff9b3cbb79f3a2e31b191bc89377c1c41981592a832ff674310effb12f3fa7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2eff9b3cbb79f3a2e31b191bc89377c1c41981592a832ff674310effb12f3fa7->enter($__internal_2eff9b3cbb79f3a2e31b191bc89377c1c41981592a832ff674310effb12f3fa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_c8f9a95a87ad8137e0f821cdcf8b0a876f1ae56d24c9dadb57b2df1447cad8d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8f9a95a87ad8137e0f821cdcf8b0a876f1ae56d24c9dadb57b2df1447cad8d8->enter($__internal_c8f9a95a87ad8137e0f821cdcf8b0a876f1ae56d24c9dadb57b2df1447cad8d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_c8f9a95a87ad8137e0f821cdcf8b0a876f1ae56d24c9dadb57b2df1447cad8d8->leave($__internal_c8f9a95a87ad8137e0f821cdcf8b0a876f1ae56d24c9dadb57b2df1447cad8d8_prof);

        
        $__internal_2eff9b3cbb79f3a2e31b191bc89377c1c41981592a832ff674310effb12f3fa7->leave($__internal_2eff9b3cbb79f3a2e31b191bc89377c1c41981592a832ff674310effb12f3fa7_prof);

    }

    // line 28
    public function block_body($context, array $blocks = array())
    {
        $__internal_4e6f97f729566798c69d490e694534b88527189cac85366c0222740df2f93133 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e6f97f729566798c69d490e694534b88527189cac85366c0222740df2f93133->enter($__internal_4e6f97f729566798c69d490e694534b88527189cac85366c0222740df2f93133_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9d6146e3d04dfda21620fe7fd0ee903bfc61b332773805d01bd4e2eaed477e4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d6146e3d04dfda21620fe7fd0ee903bfc61b332773805d01bd4e2eaed477e4c->enter($__internal_9d6146e3d04dfda21620fe7fd0ee903bfc61b332773805d01bd4e2eaed477e4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_9d6146e3d04dfda21620fe7fd0ee903bfc61b332773805d01bd4e2eaed477e4c->leave($__internal_9d6146e3d04dfda21620fe7fd0ee903bfc61b332773805d01bd4e2eaed477e4c_prof);

        
        $__internal_4e6f97f729566798c69d490e694534b88527189cac85366c0222740df2f93133->leave($__internal_4e6f97f729566798c69d490e694534b88527189cac85366c0222740df2f93133_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 28,  102 => 6,  84 => 5,  67 => 29,  65 => 28,  40 => 7,  38 => 6,  34 => 5,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Cheese Rolling - Fédération Française de Cheese Rolling{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

        <link rel=\"stylesheet\" href=\"/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css\">
        <link rel=\"stylesheet\" href=\"/css/style.css\">

        <script src=\"/js/jquery-3.2.1.js\"></script>
        <script src=\"/js/popper.min.js\"></script>
        <script src=\"/js/tether.min.js\"></script>
        <script src=\"/js/bootstrap.min.js\"></script>
        <script type=\"text/javascript\" src=\"/js/script.js\"></script>
    </head>
    <body>
        <div class=\"navbar navbar-dark bg-dark mb-4 nav-pills nav-justified\">
            <a class=\"navbar-brand\" href=\"/\" style=\"line-height:1em;font-size:1.2rem\">CHEESE ROLLING<br><span style=\"font-weight:200;letter-spacing:2px;font-size:1rem;\">Fédération Française</span></a>
            <div class=\"flex-lg-row\">
                <a class=\"navbar-brand\" href=\"/mybooks\"><i class=\"fa fa-book fa-1x\" aria-hidden=\"true\"></i>&nbsp;&nbsp;books</a>
                <a class=\"navbar-brand\" href=\"/#wifi\"><i class=\"fa fa-wifi fa-1x\" aria-hidden=\"true\"></i>&nbsp;&nbsp;Wifi</a>
            </div>
        </div>
        <div class=\"container\">
            {% block body %}{% endblock %}
        </div>
        <div class=\"footer flex-around position-relative\">
            <div class=\"footer-bloc\"><a class=\"text-secondary\" href=\"/\"><i class=\"fa fa-home fa-2x\" aria-hidden=\"true\"></i></a></div>
            <div class=\"footer-bloc text-muted copyright font-weight-light\">© Copyright FFCR 2018</div>
        </div>
    </body>
</html>
", "::base.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/app/Resources/views/base.html.twig");
    }
}
