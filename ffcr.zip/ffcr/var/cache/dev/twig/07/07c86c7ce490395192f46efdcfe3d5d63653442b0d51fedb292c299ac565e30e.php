<?php

/* CRBundle::base.html.twig */
class __TwigTemplate_8e80cbea451458bfc159b6c05c439837bde26be1343bfb864efeba8300da2e18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "CRBundle::base.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8305f21d167bc503536a31d326e2aff89bcacf61d5fd1f3c744e0f1942a8a4c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8305f21d167bc503536a31d326e2aff89bcacf61d5fd1f3c744e0f1942a8a4c4->enter($__internal_8305f21d167bc503536a31d326e2aff89bcacf61d5fd1f3c744e0f1942a8a4c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle::base.html.twig"));

        $__internal_77a599d5d2daa93a844929e57e378a51f7b73ae9f075143d183c0a7868a38b13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77a599d5d2daa93a844929e57e378a51f7b73ae9f075143d183c0a7868a38b13->enter($__internal_77a599d5d2daa93a844929e57e378a51f7b73ae9f075143d183c0a7868a38b13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle::base.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8305f21d167bc503536a31d326e2aff89bcacf61d5fd1f3c744e0f1942a8a4c4->leave($__internal_8305f21d167bc503536a31d326e2aff89bcacf61d5fd1f3c744e0f1942a8a4c4_prof);

        
        $__internal_77a599d5d2daa93a844929e57e378a51f7b73ae9f075143d183c0a7868a38b13->leave($__internal_77a599d5d2daa93a844929e57e378a51f7b73ae9f075143d183c0a7868a38b13_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3aa04c5a805b5372d6406a9f536963ca4f6c203d4a61fa66ffab3c235e94e48d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3aa04c5a805b5372d6406a9f536963ca4f6c203d4a61fa66ffab3c235e94e48d->enter($__internal_3aa04c5a805b5372d6406a9f536963ca4f6c203d4a61fa66ffab3c235e94e48d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7eb1f44bddf025864587ed1a37262995c509e297ecba0737504fc9fad573b607 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7eb1f44bddf025864587ed1a37262995c509e297ecba0737504fc9fad573b607->enter($__internal_7eb1f44bddf025864587ed1a37262995c509e297ecba0737504fc9fad573b607_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayBlock('content', $context, $blocks);
        
        $__internal_7eb1f44bddf025864587ed1a37262995c509e297ecba0737504fc9fad573b607->leave($__internal_7eb1f44bddf025864587ed1a37262995c509e297ecba0737504fc9fad573b607_prof);

        
        $__internal_3aa04c5a805b5372d6406a9f536963ca4f6c203d4a61fa66ffab3c235e94e48d->leave($__internal_3aa04c5a805b5372d6406a9f536963ca4f6c203d4a61fa66ffab3c235e94e48d_prof);

    }

    public function block_content($context, array $blocks = array())
    {
        $__internal_511783c5d99f1d933d61ef31a9fda4837a6902bd738904cea2a0fd16adc5be56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_511783c5d99f1d933d61ef31a9fda4837a6902bd738904cea2a0fd16adc5be56->enter($__internal_511783c5d99f1d933d61ef31a9fda4837a6902bd738904cea2a0fd16adc5be56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_bfc61ec2338320426e9dbbdadd970771fc7aec23ad6eeedc8b9bb9a69454d1fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfc61ec2338320426e9dbbdadd970771fc7aec23ad6eeedc8b9bb9a69454d1fd->enter($__internal_bfc61ec2338320426e9dbbdadd970771fc7aec23ad6eeedc8b9bb9a69454d1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_bfc61ec2338320426e9dbbdadd970771fc7aec23ad6eeedc8b9bb9a69454d1fd->leave($__internal_bfc61ec2338320426e9dbbdadd970771fc7aec23ad6eeedc8b9bb9a69454d1fd_prof);

        
        $__internal_511783c5d99f1d933d61ef31a9fda4837a6902bd738904cea2a0fd16adc5be56->leave($__internal_511783c5d99f1d933d61ef31a9fda4837a6902bd738904cea2a0fd16adc5be56_prof);

    }

    public function getTemplateName()
    {
        return "CRBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block body %}
    {% block content %}{% endblock %}
{% endblock %}", "CRBundle::base.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/src/CRBundle/Resources/views/base.html.twig");
    }
}
