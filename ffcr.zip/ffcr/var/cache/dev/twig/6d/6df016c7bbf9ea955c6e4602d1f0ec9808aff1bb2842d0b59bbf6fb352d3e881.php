<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_5de615a0208f2685a1eb05868ee35ffcca2bd97cf086fb0fe3f060e0bbbff1de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38cd1dca182cafe512ab9a3aba8ce24d27db6264ef969f28bf2df6148b439c03 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38cd1dca182cafe512ab9a3aba8ce24d27db6264ef969f28bf2df6148b439c03->enter($__internal_38cd1dca182cafe512ab9a3aba8ce24d27db6264ef969f28bf2df6148b439c03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_e15c07f0c1a6bd187fbbdc401f6c109dc86bd8730c7532928b7a0153545727ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e15c07f0c1a6bd187fbbdc401f6c109dc86bd8730c7532928b7a0153545727ed->enter($__internal_e15c07f0c1a6bd187fbbdc401f6c109dc86bd8730c7532928b7a0153545727ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_38cd1dca182cafe512ab9a3aba8ce24d27db6264ef969f28bf2df6148b439c03->leave($__internal_38cd1dca182cafe512ab9a3aba8ce24d27db6264ef969f28bf2df6148b439c03_prof);

        
        $__internal_e15c07f0c1a6bd187fbbdc401f6c109dc86bd8730c7532928b7a0153545727ed->leave($__internal_e15c07f0c1a6bd187fbbdc401f6c109dc86bd8730c7532928b7a0153545727ed_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_dfc0584223242d05835ae8d7d23232bfe72d483b8d6419a4367c7f7172bdb4d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dfc0584223242d05835ae8d7d23232bfe72d483b8d6419a4367c7f7172bdb4d9->enter($__internal_dfc0584223242d05835ae8d7d23232bfe72d483b8d6419a4367c7f7172bdb4d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ef2cdaef75565a6d2d6f557d598c1a3acdbb3bf90f496ed1bdcadbf7beada91b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef2cdaef75565a6d2d6f557d598c1a3acdbb3bf90f496ed1bdcadbf7beada91b->enter($__internal_ef2cdaef75565a6d2d6f557d598c1a3acdbb3bf90f496ed1bdcadbf7beada91b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_ef2cdaef75565a6d2d6f557d598c1a3acdbb3bf90f496ed1bdcadbf7beada91b->leave($__internal_ef2cdaef75565a6d2d6f557d598c1a3acdbb3bf90f496ed1bdcadbf7beada91b_prof);

        
        $__internal_dfc0584223242d05835ae8d7d23232bfe72d483b8d6419a4367c7f7172bdb4d9->leave($__internal_dfc0584223242d05835ae8d7d23232bfe72d483b8d6419a4367c7f7172bdb4d9_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b592ba16522dc011952a9acc726c3f5969d8f6c742d3f032b141e07d85f70941 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b592ba16522dc011952a9acc726c3f5969d8f6c742d3f032b141e07d85f70941->enter($__internal_b592ba16522dc011952a9acc726c3f5969d8f6c742d3f032b141e07d85f70941_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1284473900f8449acdb9b59d936e86341b639deded09dd39ca2b1fe300751fca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1284473900f8449acdb9b59d936e86341b639deded09dd39ca2b1fe300751fca->enter($__internal_1284473900f8449acdb9b59d936e86341b639deded09dd39ca2b1fe300751fca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_1284473900f8449acdb9b59d936e86341b639deded09dd39ca2b1fe300751fca->leave($__internal_1284473900f8449acdb9b59d936e86341b639deded09dd39ca2b1fe300751fca_prof);

        
        $__internal_b592ba16522dc011952a9acc726c3f5969d8f6c742d3f032b141e07d85f70941->leave($__internal_b592ba16522dc011952a9acc726c3f5969d8f6c742d3f032b141e07d85f70941_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2f4df689af7a27a6232b79f0549fc80c94dec578ffb08f70357844f62fa27aaa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f4df689af7a27a6232b79f0549fc80c94dec578ffb08f70357844f62fa27aaa->enter($__internal_2f4df689af7a27a6232b79f0549fc80c94dec578ffb08f70357844f62fa27aaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5b97a46f792f1a1315a72ad582a4655e81761ce320b1047c2e2e71e4325b63bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b97a46f792f1a1315a72ad582a4655e81761ce320b1047c2e2e71e4325b63bf->enter($__internal_5b97a46f792f1a1315a72ad582a4655e81761ce320b1047c2e2e71e4325b63bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_5b97a46f792f1a1315a72ad582a4655e81761ce320b1047c2e2e71e4325b63bf->leave($__internal_5b97a46f792f1a1315a72ad582a4655e81761ce320b1047c2e2e71e4325b63bf_prof);

        
        $__internal_2f4df689af7a27a6232b79f0549fc80c94dec578ffb08f70357844f62fa27aaa->leave($__internal_2f4df689af7a27a6232b79f0549fc80c94dec578ffb08f70357844f62fa27aaa_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
