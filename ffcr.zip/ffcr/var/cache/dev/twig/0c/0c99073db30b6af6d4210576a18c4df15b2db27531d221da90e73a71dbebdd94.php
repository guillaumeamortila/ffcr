<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b0972ea85d093d38911027a775a817705c22243169e9b5875e4b3eceefab67c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8316db9a9b1d91ef68a8cccd48094ea457afb6d0157c438a8a91248e63026db4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8316db9a9b1d91ef68a8cccd48094ea457afb6d0157c438a8a91248e63026db4->enter($__internal_8316db9a9b1d91ef68a8cccd48094ea457afb6d0157c438a8a91248e63026db4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_eb37f71d013351429dbc014982106c2d3fe02048740b478a42eeabe0a1dc1dd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb37f71d013351429dbc014982106c2d3fe02048740b478a42eeabe0a1dc1dd8->enter($__internal_eb37f71d013351429dbc014982106c2d3fe02048740b478a42eeabe0a1dc1dd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8316db9a9b1d91ef68a8cccd48094ea457afb6d0157c438a8a91248e63026db4->leave($__internal_8316db9a9b1d91ef68a8cccd48094ea457afb6d0157c438a8a91248e63026db4_prof);

        
        $__internal_eb37f71d013351429dbc014982106c2d3fe02048740b478a42eeabe0a1dc1dd8->leave($__internal_eb37f71d013351429dbc014982106c2d3fe02048740b478a42eeabe0a1dc1dd8_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5ace96f61f0ebe88789c4925cb783c27a1bc53e29658cb4d4dbb6be065191317 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ace96f61f0ebe88789c4925cb783c27a1bc53e29658cb4d4dbb6be065191317->enter($__internal_5ace96f61f0ebe88789c4925cb783c27a1bc53e29658cb4d4dbb6be065191317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f2c37bf5f96a82fb6de71800bdd9b361b6c3c526404f2b1467a4555e04e7da8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2c37bf5f96a82fb6de71800bdd9b361b6c3c526404f2b1467a4555e04e7da8d->enter($__internal_f2c37bf5f96a82fb6de71800bdd9b361b6c3c526404f2b1467a4555e04e7da8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f2c37bf5f96a82fb6de71800bdd9b361b6c3c526404f2b1467a4555e04e7da8d->leave($__internal_f2c37bf5f96a82fb6de71800bdd9b361b6c3c526404f2b1467a4555e04e7da8d_prof);

        
        $__internal_5ace96f61f0ebe88789c4925cb783c27a1bc53e29658cb4d4dbb6be065191317->leave($__internal_5ace96f61f0ebe88789c4925cb783c27a1bc53e29658cb4d4dbb6be065191317_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_215372685eb986dab795d17101c7d936e79b0f9cc823fa0b2e497338e2be8306 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_215372685eb986dab795d17101c7d936e79b0f9cc823fa0b2e497338e2be8306->enter($__internal_215372685eb986dab795d17101c7d936e79b0f9cc823fa0b2e497338e2be8306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_aee72a65576f5a51fb6e42b8bf6417a3a79a75535508834a3387539fa8110a10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aee72a65576f5a51fb6e42b8bf6417a3a79a75535508834a3387539fa8110a10->enter($__internal_aee72a65576f5a51fb6e42b8bf6417a3a79a75535508834a3387539fa8110a10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_aee72a65576f5a51fb6e42b8bf6417a3a79a75535508834a3387539fa8110a10->leave($__internal_aee72a65576f5a51fb6e42b8bf6417a3a79a75535508834a3387539fa8110a10_prof);

        
        $__internal_215372685eb986dab795d17101c7d936e79b0f9cc823fa0b2e497338e2be8306->leave($__internal_215372685eb986dab795d17101c7d936e79b0f9cc823fa0b2e497338e2be8306_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d5e727a68815d0dfe6e2435b8adaee24899f48e97b7d1e8d006f62d918bac969 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5e727a68815d0dfe6e2435b8adaee24899f48e97b7d1e8d006f62d918bac969->enter($__internal_d5e727a68815d0dfe6e2435b8adaee24899f48e97b7d1e8d006f62d918bac969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_2c6c0b3f27644873c19204ed598ab25796d3ae29dae7e918725312911f454419 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c6c0b3f27644873c19204ed598ab25796d3ae29dae7e918725312911f454419->enter($__internal_2c6c0b3f27644873c19204ed598ab25796d3ae29dae7e918725312911f454419_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_2c6c0b3f27644873c19204ed598ab25796d3ae29dae7e918725312911f454419->leave($__internal_2c6c0b3f27644873c19204ed598ab25796d3ae29dae7e918725312911f454419_prof);

        
        $__internal_d5e727a68815d0dfe6e2435b8adaee24899f48e97b7d1e8d006f62d918bac969->leave($__internal_d5e727a68815d0dfe6e2435b8adaee24899f48e97b7d1e8d006f62d918bac969_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
