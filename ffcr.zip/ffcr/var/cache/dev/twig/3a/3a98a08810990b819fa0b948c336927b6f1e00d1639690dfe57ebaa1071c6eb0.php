<?php

/* CRBundle:Default:index.html.twig */
class __TwigTemplate_a9bba466eb7bb64ebdb2794b40bbd706ab301cadbec3ab076ee8849ba08292e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("CRBundle::base.html.twig", "CRBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bd0209b49b948fadc379a0bdb3167f083b63b7f2ae9609bcc0aa9139d81b786e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd0209b49b948fadc379a0bdb3167f083b63b7f2ae9609bcc0aa9139d81b786e->enter($__internal_bd0209b49b948fadc379a0bdb3167f083b63b7f2ae9609bcc0aa9139d81b786e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:index.html.twig"));

        $__internal_225916c20b1885410d571c9ed32a35a912f8f1fe96be910712fe83f9374ca15d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_225916c20b1885410d571c9ed32a35a912f8f1fe96be910712fe83f9374ca15d->enter($__internal_225916c20b1885410d571c9ed32a35a912f8f1fe96be910712fe83f9374ca15d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bd0209b49b948fadc379a0bdb3167f083b63b7f2ae9609bcc0aa9139d81b786e->leave($__internal_bd0209b49b948fadc379a0bdb3167f083b63b7f2ae9609bcc0aa9139d81b786e_prof);

        
        $__internal_225916c20b1885410d571c9ed32a35a912f8f1fe96be910712fe83f9374ca15d->leave($__internal_225916c20b1885410d571c9ed32a35a912f8f1fe96be910712fe83f9374ca15d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a4241cba7959a350cd53d87edd7a836cf22e83b0600f9547846f3b3c663fa3c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a4241cba7959a350cd53d87edd7a836cf22e83b0600f9547846f3b3c663fa3c2->enter($__internal_a4241cba7959a350cd53d87edd7a836cf22e83b0600f9547846f3b3c663fa3c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6d88b16132b4761ac52ffab6fd2327d1a89ca9974eb647e0e76fd9a4faafa36a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d88b16132b4761ac52ffab6fd2327d1a89ca9974eb647e0e76fd9a4faafa36a->enter($__internal_6d88b16132b4761ac52ffab6fd2327d1a89ca9974eb647e0e76fd9a4faafa36a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        
        $__internal_6d88b16132b4761ac52ffab6fd2327d1a89ca9974eb647e0e76fd9a4faafa36a->leave($__internal_6d88b16132b4761ac52ffab6fd2327d1a89ca9974eb647e0e76fd9a4faafa36a_prof);

        
        $__internal_a4241cba7959a350cd53d87edd7a836cf22e83b0600f9547846f3b3c663fa3c2->leave($__internal_a4241cba7959a350cd53d87edd7a836cf22e83b0600f9547846f3b3c663fa3c2_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_3e035c49e93306810413368b813390cc703b43638682d31723a7a661ab612b74 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3e035c49e93306810413368b813390cc703b43638682d31723a7a661ab612b74->enter($__internal_3e035c49e93306810413368b813390cc703b43638682d31723a7a661ab612b74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_c734e7fc19235292cbf732e166354e3f7a51cb5ee72d736a7f242c4dc1e05498 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c734e7fc19235292cbf732e166354e3f7a51cb5ee72d736a7f242c4dc1e05498->enter($__internal_c734e7fc19235292cbf732e166354e3f7a51cb5ee72d736a7f242c4dc1e05498_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"my-4\">Let's roll the cheese !!</h1>
";
        
        $__internal_c734e7fc19235292cbf732e166354e3f7a51cb5ee72d736a7f242c4dc1e05498->leave($__internal_c734e7fc19235292cbf732e166354e3f7a51cb5ee72d736a7f242c4dc1e05498_prof);

        
        $__internal_3e035c49e93306810413368b813390cc703b43638682d31723a7a661ab612b74->leave($__internal_3e035c49e93306810413368b813390cc703b43638682d31723a7a661ab612b74_prof);

    }

    public function getTemplateName()
    {
        return "CRBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"CRBundle::base.html.twig\" %}

{% block title %}{{ parent() }}{% endblock %}

{% block content %}
    <h1 class=\"my-4\">Let's roll the cheese !!</h1>
{% endblock %}", "CRBundle:Default:index.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/src/CRBundle/Resources/views/Default/index.html.twig");
    }
}
