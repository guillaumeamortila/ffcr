<?php

/* CRBundle:Default:presentation.html.twig */
class __TwigTemplate_e5cfebd577c6f4b8074dc78cab464eac819afb30f71b71fcce02a7fc09ebfd08 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("CRBundle::base.html.twig", "CRBundle:Default:presentation.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_913a39bd958840a566b567f5f2f012ed6266162e4a2616235dc755990379a8d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_913a39bd958840a566b567f5f2f012ed6266162e4a2616235dc755990379a8d4->enter($__internal_913a39bd958840a566b567f5f2f012ed6266162e4a2616235dc755990379a8d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:presentation.html.twig"));

        $__internal_cd4bab747bfb7b454e0ca79837b47bc8f1b418d98b95e3ffc26ddfedaab44ec3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd4bab747bfb7b454e0ca79837b47bc8f1b418d98b95e3ffc26ddfedaab44ec3->enter($__internal_cd4bab747bfb7b454e0ca79837b47bc8f1b418d98b95e3ffc26ddfedaab44ec3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:presentation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_913a39bd958840a566b567f5f2f012ed6266162e4a2616235dc755990379a8d4->leave($__internal_913a39bd958840a566b567f5f2f012ed6266162e4a2616235dc755990379a8d4_prof);

        
        $__internal_cd4bab747bfb7b454e0ca79837b47bc8f1b418d98b95e3ffc26ddfedaab44ec3->leave($__internal_cd4bab747bfb7b454e0ca79837b47bc8f1b418d98b95e3ffc26ddfedaab44ec3_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_8991790a19f4a382c7f3fc56c07ab814f563d9466c5b906b6c6d8d222dc11f07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8991790a19f4a382c7f3fc56c07ab814f563d9466c5b906b6c6d8d222dc11f07->enter($__internal_8991790a19f4a382c7f3fc56c07ab814f563d9466c5b906b6c6d8d222dc11f07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_bc27d23bb5ddf2da03daf280052a29d7a50bc5e2996eeca55c5398f5b90ab8d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc27d23bb5ddf2da03daf280052a29d7a50bc5e2996eeca55c5398f5b90ab8d8->enter($__internal_bc27d23bb5ddf2da03daf280052a29d7a50bc5e2996eeca55c5398f5b90ab8d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        
        $__internal_bc27d23bb5ddf2da03daf280052a29d7a50bc5e2996eeca55c5398f5b90ab8d8->leave($__internal_bc27d23bb5ddf2da03daf280052a29d7a50bc5e2996eeca55c5398f5b90ab8d8_prof);

        
        $__internal_8991790a19f4a382c7f3fc56c07ab814f563d9466c5b906b6c6d8d222dc11f07->leave($__internal_8991790a19f4a382c7f3fc56c07ab814f563d9466c5b906b6c6d8d222dc11f07_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_8196027268326c4ee53bdf23491897ee9aff3b236789042b6df6f984972d49f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8196027268326c4ee53bdf23491897ee9aff3b236789042b6df6f984972d49f0->enter($__internal_8196027268326c4ee53bdf23491897ee9aff3b236789042b6df6f984972d49f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_f034b1ecb1ca6820930913fc9d517a9d81833854235ae812a8a4b418065598c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f034b1ecb1ca6820930913fc9d517a9d81833854235ae812a8a4b418065598c8->enter($__internal_f034b1ecb1ca6820930913fc9d517a9d81833854235ae812a8a4b418065598c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"my-4\">Qu'est-ce que le Cheese Rolling ?</h1>
    <img src=\"https://i2-prod.gloucestershirelive.co.uk/incoming/article79922.ece/ALTERNATES/s615b/Competitors-take-part-in-the-annual-unofficial-cheese-rolling-at-Coopers-Hill-in-Brockworth.jpg\">
    <div>
        <ul class=\"list-unstyled\">
            <li>20 personnes au départ</li>
            <li>Une côte naturelle, plus ou moins pentue</li>
            <li>L'arbitre, en haut, lance le fromage et marque le départ</li>
            <li>4 catégories de course</li>
            <li>Des premiers soins pour les plus intrépides</li>
        </ul>
        <p>Chaque année, la célèbre Cheese Rolling Race a lieu à Brockworth, dans le Gloucestershire (Royaume-Uni). Le principe est simple: l'arbitre lâche un fromage rond depuis le sommet d’une colline, le vainqueur est celui ou celle qui attrape le fromage 200 mètres plus bas - qui arrive en tête. Pour emporter la victoire et le fromage de près de quatre kilos, il faut donc éviter de tomber ou d’être emporté par un concurrent dans sa chute. L’attraper en course est pratiquement impossible, le champion est donc celui qui termine la descente sur ses deux jambes. Plusieurs lancers sont organisés pour différentes catégories. Il en existe une pour les enfants, bien moins dangereuse que celle des adultes. Un des gagnants habitués est Chris Anderson, un vrai spécialiste: en dix ans, il a remporté quinze fromage. Chez les femmes, c’est l’adolescente de 16 ans Keavy Morgan qui s’est imposée à la dernière course avant d'admettre qu’elle n’aimait pas le fromage…</p>
    </div>
";
        
        $__internal_f034b1ecb1ca6820930913fc9d517a9d81833854235ae812a8a4b418065598c8->leave($__internal_f034b1ecb1ca6820930913fc9d517a9d81833854235ae812a8a4b418065598c8_prof);

        
        $__internal_8196027268326c4ee53bdf23491897ee9aff3b236789042b6df6f984972d49f0->leave($__internal_8196027268326c4ee53bdf23491897ee9aff3b236789042b6df6f984972d49f0_prof);

    }

    public function getTemplateName()
    {
        return "CRBundle:Default:presentation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"CRBundle::base.html.twig\" %}

{% block title %}{{ parent() }}{% endblock %}

{% block content %}
    <h1 class=\"my-4\">Qu'est-ce que le Cheese Rolling ?</h1>
    <img src=\"https://i2-prod.gloucestershirelive.co.uk/incoming/article79922.ece/ALTERNATES/s615b/Competitors-take-part-in-the-annual-unofficial-cheese-rolling-at-Coopers-Hill-in-Brockworth.jpg\">
    <div>
        <ul class=\"list-unstyled\">
            <li>20 personnes au départ</li>
            <li>Une côte naturelle, plus ou moins pentue</li>
            <li>L'arbitre, en haut, lance le fromage et marque le départ</li>
            <li>4 catégories de course</li>
            <li>Des premiers soins pour les plus intrépides</li>
        </ul>
        <p>Chaque année, la célèbre Cheese Rolling Race a lieu à Brockworth, dans le Gloucestershire (Royaume-Uni). Le principe est simple: l'arbitre lâche un fromage rond depuis le sommet d’une colline, le vainqueur est celui ou celle qui attrape le fromage 200 mètres plus bas - qui arrive en tête. Pour emporter la victoire et le fromage de près de quatre kilos, il faut donc éviter de tomber ou d’être emporté par un concurrent dans sa chute. L’attraper en course est pratiquement impossible, le champion est donc celui qui termine la descente sur ses deux jambes. Plusieurs lancers sont organisés pour différentes catégories. Il en existe une pour les enfants, bien moins dangereuse que celle des adultes. Un des gagnants habitués est Chris Anderson, un vrai spécialiste: en dix ans, il a remporté quinze fromage. Chez les femmes, c’est l’adolescente de 16 ans Keavy Morgan qui s’est imposée à la dernière course avant d'admettre qu’elle n’aimait pas le fromage…</p>
    </div>
{% endblock %}", "CRBundle:Default:presentation.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/src/CRBundle/Resources/views/Default/presentation.html.twig");
    }
}
