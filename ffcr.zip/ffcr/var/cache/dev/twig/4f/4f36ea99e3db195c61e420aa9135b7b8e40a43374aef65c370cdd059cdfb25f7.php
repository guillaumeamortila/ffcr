<?php

/* CRBundle:Default:terrain.html.twig */
class __TwigTemplate_f4a6f427d75db13d038182bd6d8cbf93f802479d1566fb1ccdd262d8590e6ba9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("CRBundle::base.html.twig", "CRBundle:Default:terrain.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CRBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_509702e3c4c514a9408ebdf054e3a1bbc1ca1cbbc4a2cc04f64e8fd6822ab55d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_509702e3c4c514a9408ebdf054e3a1bbc1ca1cbbc4a2cc04f64e8fd6822ab55d->enter($__internal_509702e3c4c514a9408ebdf054e3a1bbc1ca1cbbc4a2cc04f64e8fd6822ab55d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:terrain.html.twig"));

        $__internal_17b3f15641b296f88eb0723d84fd2411f81ff693bdd4eb6ee21c994b2a882506 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17b3f15641b296f88eb0723d84fd2411f81ff693bdd4eb6ee21c994b2a882506->enter($__internal_17b3f15641b296f88eb0723d84fd2411f81ff693bdd4eb6ee21c994b2a882506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CRBundle:Default:terrain.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_509702e3c4c514a9408ebdf054e3a1bbc1ca1cbbc4a2cc04f64e8fd6822ab55d->leave($__internal_509702e3c4c514a9408ebdf054e3a1bbc1ca1cbbc4a2cc04f64e8fd6822ab55d_prof);

        
        $__internal_17b3f15641b296f88eb0723d84fd2411f81ff693bdd4eb6ee21c994b2a882506->leave($__internal_17b3f15641b296f88eb0723d84fd2411f81ff693bdd4eb6ee21c994b2a882506_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_e9751b55eb35c9a32880640a6b41439ea660ab484baa3e63501d8b1c622abb7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e9751b55eb35c9a32880640a6b41439ea660ab484baa3e63501d8b1c622abb7a->enter($__internal_e9751b55eb35c9a32880640a6b41439ea660ab484baa3e63501d8b1c622abb7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_df2b0e93fc010baee831b882e549617f7ad6f5a1f45d8af0c35c9cabcc7f5c6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df2b0e93fc010baee831b882e549617f7ad6f5a1f45d8af0c35c9cabcc7f5c6d->enter($__internal_df2b0e93fc010baee831b882e549617f7ad6f5a1f45d8af0c35c9cabcc7f5c6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        
        $__internal_df2b0e93fc010baee831b882e549617f7ad6f5a1f45d8af0c35c9cabcc7f5c6d->leave($__internal_df2b0e93fc010baee831b882e549617f7ad6f5a1f45d8af0c35c9cabcc7f5c6d_prof);

        
        $__internal_e9751b55eb35c9a32880640a6b41439ea660ab484baa3e63501d8b1c622abb7a->leave($__internal_e9751b55eb35c9a32880640a6b41439ea660ab484baa3e63501d8b1c622abb7a_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_5af543046f2b8e6b9b2ed5aa63a20a8c0ce0798b755223c4b7d39a949462392d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5af543046f2b8e6b9b2ed5aa63a20a8c0ce0798b755223c4b7d39a949462392d->enter($__internal_5af543046f2b8e6b9b2ed5aa63a20a8c0ce0798b755223c4b7d39a949462392d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_7773594ac12a1401f92ccf3cf67f3b2325acce17ccf72effaa4c2b883ae5ab78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7773594ac12a1401f92ccf3cf67f3b2325acce17ccf72effaa4c2b883ae5ab78->enter($__internal_7773594ac12a1401f92ccf3cf67f3b2325acce17ccf72effaa4c2b883ae5ab78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    <h1 class=\"my-4\">Proposez un terrain à l'homologation de la FFCR</h1>

    <form>
        <div class=\"form-group\">
            <label for=\"nom\">Nom</label>
            <input type=\"text\" name=\"nom\" minlength=\"3\" required placeholder=\"Nom\" class=\"form-control\" id=\"nom\">
        </div>
        <div class=\"form-group\">
            <label for=\"prenom\">Prénom</label>
            <input type=\"text\" name=\"prenom\" minlength=\"3\" required placeholder=\"Prénom\" class=\"form-control\" id=\"prenom\">
        </div>
        <div class=\"form-group\">
            <label for=\"email\">Email</label>
            <input type=\"email\" name=\"email\" minlength=\"3\" required placeholder=\"Email\" class=\"form-control\" id=\"email\">
        </div>
        <div class=\"form-group\">
            <label for=\"tel\">Téléphone</label>
            <input type=\"tel\" name=\"tel\" minlength=\"3\" required placeholder=\"Numéro de téléphone\" class=\"form-control\" id=\"tel\">
        </div>
        <div class=\"form-group\">
            <label for=\"adresse\">Adresse du terrain</label>
            <input type=\"text\" name=\"adresse\" minlength=\"3\" required placeholder=\"tel\" class=\"form-control\" id=\"adresse\">
        </div>
        <input type=\"submit\" class=\"btn btn-outline-success form-control mb-5 mt-3\">
    </form>
";
        
        $__internal_7773594ac12a1401f92ccf3cf67f3b2325acce17ccf72effaa4c2b883ae5ab78->leave($__internal_7773594ac12a1401f92ccf3cf67f3b2325acce17ccf72effaa4c2b883ae5ab78_prof);

        
        $__internal_5af543046f2b8e6b9b2ed5aa63a20a8c0ce0798b755223c4b7d39a949462392d->leave($__internal_5af543046f2b8e6b9b2ed5aa63a20a8c0ce0798b755223c4b7d39a949462392d_prof);

    }

    public function getTemplateName()
    {
        return "CRBundle:Default:terrain.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"CRBundle::base.html.twig\" %}

{% block title %}{{ parent() }}{% endblock %}

{% block content %}
    <h1 class=\"my-4\">Proposez un terrain à l'homologation de la FFCR</h1>

    <form>
        <div class=\"form-group\">
            <label for=\"nom\">Nom</label>
            <input type=\"text\" name=\"nom\" minlength=\"3\" required placeholder=\"Nom\" class=\"form-control\" id=\"nom\">
        </div>
        <div class=\"form-group\">
            <label for=\"prenom\">Prénom</label>
            <input type=\"text\" name=\"prenom\" minlength=\"3\" required placeholder=\"Prénom\" class=\"form-control\" id=\"prenom\">
        </div>
        <div class=\"form-group\">
            <label for=\"email\">Email</label>
            <input type=\"email\" name=\"email\" minlength=\"3\" required placeholder=\"Email\" class=\"form-control\" id=\"email\">
        </div>
        <div class=\"form-group\">
            <label for=\"tel\">Téléphone</label>
            <input type=\"tel\" name=\"tel\" minlength=\"3\" required placeholder=\"Numéro de téléphone\" class=\"form-control\" id=\"tel\">
        </div>
        <div class=\"form-group\">
            <label for=\"adresse\">Adresse du terrain</label>
            <input type=\"text\" name=\"adresse\" minlength=\"3\" required placeholder=\"tel\" class=\"form-control\" id=\"adresse\">
        </div>
        <input type=\"submit\" class=\"btn btn-outline-success form-control mb-5 mt-3\">
    </form>
{% endblock %}", "CRBundle:Default:terrain.html.twig", "/Users/guillaumeamortila/workshop-3/ffcr/ffcr/src/CRBundle/Resources/views/Default/terrain.html.twig");
    }
}
